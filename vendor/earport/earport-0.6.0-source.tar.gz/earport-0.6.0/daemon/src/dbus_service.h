/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileCopyrightText: 2024 EarPort Contributors
 *
 * D-Bus service interface for GNOME extension communication
 */

#ifndef DBUS_SERVICE_H
#define DBUS_SERVICE_H

#include <glib.h>
#include <gio/gio.h>
#include "airpods_state.h"

/* D-Bus service constants */
#define DBUS_SERVICE_NAME       "io.github.anoryth.EarPort"
#define DBUS_OBJECT_PATH        "/io/github/anoryth/EarPort"
#define DBUS_INTERFACE_NAME     "io.github.anoryth.EarPort1"

/* Commands sent to the AirPods: the callbacks return false if they could
 * not be sent (AirPods not connected), and the method then fails */

/* Callback for noise control mode change request */
typedef bool (*DbusNoiseControlCallback)(NoiseControlMode mode, void *user_data);

/* Callback for conversational awareness change request */
typedef bool (*DbusConvAwarenessCallback)(bool enabled, void *user_data);

/* Callback for adaptive noise level change request */
typedef bool (*DbusAdaptiveLevelCallback)(int level, void *user_data);

/* Callback for ear pause mode change request */
typedef void (*DbusEarPauseModeCallback)(int mode, void *user_data);

/* Callback for listening modes configuration change request */
typedef bool (*DbusListeningModesCallback)(bool off, bool transparency, bool anc, bool adaptive, void *user_data);

/* Callback for display name change request */
typedef void (*DbusDisplayNameCallback)(const char *name, void *user_data);
/* An action on the AirPods; false if they are not connected */
typedef bool (*DbusActionCallback)(void *user_data);

/* D-Bus service context */
/* Callback for generic settings: byte is the validated value to send.
 * Returns false if it could not be sent (AirPods not connected). */
typedef bool (*DbusSettingCallback)(const AirPodsSettingDef *def, uint8_t byte, void *user_data);

/* Callback for the automatic connection option */
typedef void (*DbusAutoConnectCallback)(bool enabled, void *user_data);

typedef struct DbusService DbusService;

/**
 * Create a new D-Bus service
 *
 * @param state Pointer to AirPods state (must remain valid)
 * @return New service or NULL on error
 */
DbusService *dbus_service_new(AirPodsState *state);

/**
 * Free D-Bus service
 */
void dbus_service_free(DbusService *service);

/**
 * Start the D-Bus service (acquire bus name)
 *
 * @return true on success
 */
bool dbus_service_start(DbusService *service);

/**
 * Stop the D-Bus service
 */
void dbus_service_stop(DbusService *service);

/**
 * Set callback for noise control mode change requests
 */
void dbus_service_set_noise_control_callback(DbusService *service,
                                              DbusNoiseControlCallback callback,
                                              void *user_data);

/**
 * Set callback for conversational awareness change requests
 */
void dbus_service_set_conv_awareness_callback(DbusService *service,
                                               DbusConvAwarenessCallback callback,
                                               void *user_data);

/**
 * Set callback for adaptive noise level change requests
 */
void dbus_service_set_adaptive_level_callback(DbusService *service,
                                               DbusAdaptiveLevelCallback callback,
                                               void *user_data);

/**
 * Set callback for ear pause mode change requests
 */
void dbus_service_set_ear_pause_mode_callback(DbusService *service,
                                               DbusEarPauseModeCallback callback,
                                               void *user_data);

/**
 * Set callback for listening modes configuration change requests
 */
void dbus_service_set_listening_modes_callback(DbusService *service,
                                                DbusListeningModesCallback callback,
                                                void *user_data);

/**
 * Set callback for generic setting change requests (SetSetting)
 */
void dbus_service_set_setting_callback(DbusService *service,
                                        DbusSettingCallback callback,
                                        void *user_data);

/**
 * Set callback and current value of the automatic connection option
 */
void dbus_service_set_auto_connect_callback(DbusService *service,
                                            DbusAutoConnectCallback callback,
                                            void *user_data);
void dbus_service_set_auto_connect(DbusService *service, bool enabled);

/* "Switch with your Apple devices" option (same callback shape) */
void dbus_service_set_apple_handoff_callback(DbusService *service,
                                             DbusAutoConnectCallback callback,
                                             void *user_data);
void dbus_service_set_apple_handoff(DbusService *service, bool enabled);

/* Connecting the AirPods again after an Apple device took them: clients
 * keep quiet about the disconnection meanwhile */
void dbus_service_set_reconnecting(DbusService *service, bool reconnecting);

/* ResearchSend: a raw packet to the AirPods, only in research mode
 * (research_log=true); false if refused or not connected */
typedef bool (*DbusRawCallback)(const uint8_t *data, size_t len, void *user_data);
void dbus_service_set_research_send_callback(DbusService *service,
                                             DbusRawCallback callback,
                                             void *user_data);

/* ClaimAudio: have the AirPods play from this computer */
void dbus_service_set_claim_audio_callback(DbusService *service,
                                           DbusActionCallback callback,
                                           void *user_data);

/**
 * Set callback for display name change requests
 */
void dbus_service_set_display_name_callback(DbusService *service,
                                             DbusDisplayNameCallback callback,
                                             void *user_data);

/**
 * Emit DeviceConnected signal
 */
void dbus_service_emit_device_connected(DbusService *service,
                                         const char *address,
                                         const char *name);

/**
 * Emit DeviceDisconnected signal
 */
void dbus_service_emit_device_disconnected(DbusService *service,
                                            const char *address,
                                            const char *name);

/**
 * Emit BatteryChanged signal
 */
void dbus_service_emit_battery_changed(DbusService *service,
                                        int left, int right, int case_battery);

/**
 * Emit NoiseControlModeChanged signal
 */
void dbus_service_emit_noise_control_changed(DbusService *service,
                                              NoiseControlMode mode);

/**
 * Emit EarDetectionChanged signal
 */
void dbus_service_emit_ear_detection_changed(DbusService *service,
                                              bool left_in_ear,
                                              bool right_in_ear);

/**
 * Emit SpeakingChanged: conversation awareness detected the user started
 * (true) or stopped (false) speaking. Clients lower/restore the volume.
 */
void dbus_service_emit_speaking_changed(DbusService *service, bool speaking);

/* Playback was paused because the user fell asleep (once per pause) */
void dbus_service_emit_paused_for_sleep(DbusService *service);

/**
 * Notify that a property has changed (emits PropertiesChanged)
 */
void dbus_service_emit_properties_changed(DbusService *service,
                                           const char *property_name);

#endif /* DBUS_SERVICE_H */
